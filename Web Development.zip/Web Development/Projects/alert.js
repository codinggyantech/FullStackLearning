console.log("Alert file")
// alert("hi")
// console.log("move")
// alert("bye")


// a = prompt("Enter you name")
// console.log(a)

a = "ram"
b = "shyaam"

c = a+b;
console.log(c)

//Making a addtion program in JS
 a = prompt("Enter a value");
 b = prompt("Enter b value: ");
//  c = `${a}+${b}`
console.log(typeof(a+"+"+b))
 console.log("The additon is: ",eval(a+"+"+b))