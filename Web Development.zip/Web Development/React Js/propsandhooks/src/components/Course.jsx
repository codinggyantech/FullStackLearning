import React from 'react'

const Course = ({mycourse}) => {
  return (
    <div>Course :{mycourse}</div>
  )
}

export default Course