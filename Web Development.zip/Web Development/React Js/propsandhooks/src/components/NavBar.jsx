function NavBar(){

    return(
      <>  
      
      
      <div className="flex">
        <div>Logo</div>
        <div>
            <ul className="flex">
                <li>Home </li>
                <li>About us</li>
            </ul>
        </div>
      </div>
        
      
      </>
    )
  }

export default NavBar;