import React from 'react'

const PageNotFound = () => {
  return (
    <div>
        <img src="https://img.freepik.com/free-vector/error-404-concept-landing-page_52683-10996.jpg?size=626&ext=jpg&ga=GA1.2.1835727658.1662645668" alt="" />
    </div>
  )
}

export default PageNotFound