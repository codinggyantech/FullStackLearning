import User from "./User"

function App() {
  return (
    <div>
 <h1> HI Welcom to react js</h1>
 <p> hello i am a para</p>
 <hr/>
<User name="Ram" />
<User name="Shyam"/>
<User name="Krishna"/>
<User name="Martin"/>
  
 
  
  
   </div>
   
  );
}

export default App;
