function Profile(){
    return(
      <div>
      <h3> hi profile component here </h3>
      <p> I am from Profile compoentns</p>
      </div>)
  }

  export default Profile