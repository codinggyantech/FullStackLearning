function Home (){
    return (
        <div>
<h1> HOME Component</h1>
            </div>
    )
}

export default Home;