import Profile from "./Profile";



function User({name}){
    return(
      <div>
      <h3> hi {name}</h3>
     <Profile/>
      </div> 
    )
  }
  
  

  export default User

  