console.log("Hello World !")
console.log("hi my name is coder !!😊")