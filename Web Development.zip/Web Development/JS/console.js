//Simple console stmt
console.log("Learning about console window ")
// error in console
console.error("Showing Errors ")
// info in cosole 
console.info("INformation showing")
// warning in console
console.warn("waring msg")

a = ["hi",2,3,4]
b = {
    "name": "bablu",
    "age":22,
    "gender": "Male"
}
console.table(a)
console.log(b)
console.table(b)
