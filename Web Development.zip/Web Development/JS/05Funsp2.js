console.log("Learning Functions:")

/**
 * Add two number:
 * 
 */

a = 3;
b = 5;
// console.log("The Number a is: ",a)
// console.log("The Number b is: ",b)
// console.log("The sum of a and b is ",a+b)
a= 10
b =20;


function addingNUmbers(a,b){
    console.log("The Number a is: ",a)
console.log("The Number b is: ",b)
console.log("The sum of a and b is ",a+b)

}

// addingNUmbers(15,15)
// addingNUmbers(40,60)


const newfun = () =>{
    console.log("Inside the New function")
}

// newfun()


// Traditon Greeting function 
 
function Greet(name){
    console.log("Hi Good Morning",name)
    console.log(name,"bye have a nice day")
}

// Greet("Rohan")
// Greet("Raju")


 Bye = ()=> {
    console.log("Hi Welcome to bye function ")
 console.log("hi")
 }

// Bye()

