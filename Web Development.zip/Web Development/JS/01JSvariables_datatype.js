console.log("Data Types and Variables: ")

// 1. comments in Js :
/* 
***************
There are two types of comments:
 1. single line comments
 2. MUlti line comments

 */

// Variables in Js : 

// let  a = 2;
// console.log(a)
// a = "Rohit"
// console.log(a)

// b = "roshan singh";
// b = true
// b = 45.5
// b
// console.log(b)

//rules to create the varibles:
// let bablu = "hi"
// let 5bablu = 2; cannot start with numbers
let demo$work =" hi"
let demo_work = "hi"
// let hello@rohan = "hi"; it cannot have the special character except( $ _)


//Data types in Js:

let a = 2;
a = 2.455
a= "bablu"
a = true


a = null
console.log(a, typeof(a))

console.log(typeof(ulbab))

//Escape squences  \n ==> new line  \t=> for the tab

console.log("hi ","hello \n ","\t\hey");


// \n example
console.log("HI \n\n\n\n World !")
// \t example 
console.log("hi \t\t\t world") 