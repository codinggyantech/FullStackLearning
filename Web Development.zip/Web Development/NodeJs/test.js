console.log("running in node js")
let a=3
let b = 5
console.log(a+b)
const os = require('node:os');
console.log(os.freemem())
console.log(os.totalmem())
console.log(os.platform())