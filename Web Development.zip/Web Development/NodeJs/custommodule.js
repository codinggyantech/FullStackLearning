function callAvg(a,b,c){
    console.log("callAvg",(a+b+c)/3);
}

function grettings(name){
    console.log("grettings Welcome to our site",name);

}
module.exports =  {callAvg,grettings}