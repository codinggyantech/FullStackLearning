console.log("New file")
const myMod = require("./custommodule");
// myMod.
console.log(myMod) 
myMod.grettings('Rohan')