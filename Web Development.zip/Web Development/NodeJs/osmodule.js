const os = require("os")


console.log("OS MODULE")

// console.log(os.networkInterfaces())
// console.log(os.freemem())
console.log(os.homedir())
console.log(os.hostname())
console.log(os.uptime())
console.log(os.userInfo())
