import React from 'react'

const PageNotFound = () => {
  return (
    <div>
        <h1 className='text-center text-danger'>
        PageNotFound 404
        </h1>
    </div>
  )
}

export default PageNotFound